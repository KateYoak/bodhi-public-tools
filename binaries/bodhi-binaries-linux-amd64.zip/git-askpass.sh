#!/bin/sh
# GIT_ASKPASS helper — echoes BODHI_GIT_PAT for HTTPS git (never log).
exec printf '%s\n' "$BODHI_GIT_PAT"
